<div class="bg-dark text-white p-3" style="min-height: 100vh;">
    <h4>🎨 Designer Panel</h4>
    <ul class="nav flex-column">
        <li class="nav-item"><a href="{{ route('designer.dashboard') }}" class="nav-link text-white">📦 Requests</a></li>
        <li class="nav-item"><a href="{{ route('designer.recustomization') }}" class="nav-link text-white">🔁 Re-Customization</a></li>
        <li class="nav-item"><a href="{{ route('designer.chats') }}" class="nav-link text-white">💬 Chats</a></li>
    </ul>
</div>
